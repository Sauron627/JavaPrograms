import java.io.IOException;


public class Runner {

	public static void main(String[] args) throws IOException {
		
		LakoTelepReader.read("input.txt");		
	}

}
